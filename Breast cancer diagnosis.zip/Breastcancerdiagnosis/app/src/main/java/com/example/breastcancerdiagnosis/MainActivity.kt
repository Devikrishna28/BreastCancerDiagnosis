package com.example.breastcancerdiagnosis

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.breastcancerdiagnosis.ui.theme.BreastCancerDiagnosisTheme
import java.util.Locale

class MainActivity : ComponentActivity() {

    private lateinit var inferenceEngine: ModelInferenceEngine

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        inferenceEngine = ModelInferenceEngine(this)

        setContent {
            BreastCancerDiagnosisTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    BreastCancerApp(inferenceEngine = inferenceEngine)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BreastCancerApp(inferenceEngine: ModelInferenceEngine) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    // 30 feature input states initialized with benign preset defaults
    val inputValues = remember {
        mutableStateListOf<String>().apply {
            if (inferenceEngine.isReady) {
                inferenceEngine.benignPreset.forEach {
                    add(String.format(Locale.US, "%.4f", it))
                }
            } else {
                repeat(30) { add("0.0") }
            }
        }
    }

    var predictionResult by remember { mutableStateOf<PredictionResult?>(null) }

    // Run initial prediction if ready
    LaunchedEffect(inferenceEngine.isReady) {
        if (inferenceEngine.isReady && predictionResult == null) {
            val dArray = DoubleArray(30) { inputValues[it].toDoubleOrNull() ?: 0.0 }
            predictionResult = inferenceEngine.predict(dArray)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "🔬 OncoPredict AI",
                            fontSize = 19.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "Breast Cancer Classifier (CO5)",
                            fontSize = 12.sp,
                            color = Color(0xFFBFDBFE)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF1E3A8A)
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp)
                .verticalScroll(scrollState),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(modifier = Modifier.height(4.dp))

            // Quick Presets Card
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "⚡ Quick Testing Presets",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "Instantly load verified biopsy cytology samples:",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                        modifier = Modifier.padding(vertical = 6.dp)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                if (inferenceEngine.isReady) {
                                    inferenceEngine.malignantPreset.forEachIndexed { i, v ->
                                        inputValues[i] = String.format(Locale.US, "%.4f", v)
                                    }
                                    val dArray = DoubleArray(30) { inputValues[it].toDoubleOrNull() ?: 0.0 }
                                    predictionResult = inferenceEngine.predict(dArray)
                                    Toast.makeText(context, "Loaded Malignant Biopsy Sample", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Malignant", fontSize = 13.sp, color = Color.White)
                        }

                        Button(
                            onClick = {
                                if (inferenceEngine.isReady) {
                                    inferenceEngine.benignPreset.forEachIndexed { i, v ->
                                        inputValues[i] = String.format(Locale.US, "%.4f", v)
                                    }
                                    val dArray = DoubleArray(30) { inputValues[it].toDoubleOrNull() ?: 0.0 }
                                    predictionResult = inferenceEngine.predict(dArray)
                                    Toast.makeText(context, "Loaded Benign Biopsy Sample", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Benign", fontSize = 13.sp, color = Color.White)
                        }
                    }
                }
            }

            // Prediction Result Card
            predictionResult?.let { res ->
                val isMalignant = res.predictedClass == 0
                val cardBg = if (isMalignant) Color(0xFFFEE2E2) else Color(0xFFDCFCE7)
                val textColor = if (isMalignant) Color(0xFF991B1B) else Color(0xFF166534)
                val badgeColor = if (isMalignant) Color(0xFFDC2626) else Color(0xFF16A34A)

                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = cardBg),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = if (isMalignant) "🚨 MALIGNANT DETECTED" else "✅ BENIGN DETECTED",
                                fontWeight = FontWeight.Bold,
                                fontSize = 17.sp,
                                color = badgeColor
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        LinearProgressIndicator(
                            progress = { (res.probMalignant / 100.0).toFloat() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(10.dp),
                            color = Color(0xFFDC2626),
                            trackColor = Color(0xFF86EFAC)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = String.format(
                                Locale.US,
                                "Malignancy Risk: %.2f%% | Benign: %.2f%%",
                                res.probMalignant,
                                res.probBenign
                            ),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = textColor
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = res.clinicalAdvice,
                            fontSize = 12.sp,
                            color = textColor.copy(alpha = 0.9f)
                        )
                    }
                }
            }

            // Run Prediction Button
            Button(
                onClick = {
                    val dArray = DoubleArray(30)
                    for (i in 0 until 30) {
                        val num = inputValues[i].toDoubleOrNull()
                        if (num == null) {
                            Toast.makeText(context, "Please enter valid numbers for all 30 features.", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        dArray[i] = num
                    }
                    predictionResult = inferenceEngine.predict(dArray)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E3A8A))
            ) {
                Text(
                    text = "🚀 Run AI Diagnostic Analysis",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            // Feature Inputs Header
            Text(
                text = "📋 FNA Nuclear Morphometric Features (30 Inputs)",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )

            // Dynamic Categorized Inputs
            if (inferenceEngine.isReady) {
                var lastCategory = ""
                inferenceEngine.featureNames.forEachIndexed { index, rawName ->
                    val category = when {
                        rawName.contains("mean") -> "1. Mean Cell Nuclei Metrics"
                        rawName.contains("error") -> "2. Standard Error Metrics"
                        else -> "3. Worst / Extreme Metrics"
                    }

                    if (category != lastCategory) {
                        lastCategory = category
                        Text(
                            text = category,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1E3A8A),
                            modifier = Modifier.padding(top = 10.dp, bottom = 4.dp)
                        )
                    }

                    OutlinedTextField(
                        value = inputValues[index],
                        onValueChange = { inputValues[index] = it },
                        label = {
                            Text(
                                rawName.split(" ").joinToString(" ") { it.replaceFirstChar(Char::titlecase) },
                                fontSize = 13.sp
                            )
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}