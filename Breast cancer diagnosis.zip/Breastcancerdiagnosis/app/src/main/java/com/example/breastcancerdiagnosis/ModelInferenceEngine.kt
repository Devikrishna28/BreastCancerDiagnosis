package com.example.breastcancerdiagnosis

import android.content.Context
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import kotlin.math.exp

data class PredictionResult(
    val predictedClass: Int, // 0 = Malignant, 1 = Benign
    val probMalignant: Double, // 0.0 to 100.0%
    val probBenign: Double,    // 0.0 to 100.0%
    val diagnosisLabel: String,
    val clinicalAdvice: String
)

class ModelInferenceEngine(context: Context) {

    lateinit var featureNames: Array<String>
        private set
    lateinit var scalerMean: DoubleArray
        private set
    lateinit var scalerScale: DoubleArray
        private set
    lateinit var weights: DoubleArray
        private set
    var intercept: Double = 0.0
        private set
    lateinit var malignantPreset: DoubleArray
        private set
    lateinit var benignPreset: DoubleArray
        private set

    var isReady: Boolean = false
        private set

    init {
        loadModelParameters(context)
    }

    private fun loadModelParameters(context: Context) {
        try {
            val inputStream = context.assets.open("model_parameters.json")
            val size = inputStream.available()
            val buffer = ByteArray(size)
            inputStream.read(buffer)
            inputStream.close()

            val jsonString = String(buffer, StandardCharsets.UTF_8)
            val json = JSONObject(jsonString)

            val jsonNames = json.getJSONArray("feature_names")
            val jsonMean = json.getJSONArray("scaler_mean")
            val jsonScale = json.getJSONArray("scaler_scale")
            val jsonWeights = json.getJSONArray("weights")
            val jsonMal = json.getJSONArray("malignant_preset")
            val jsonBen = json.getJSONArray("benign_preset")

            val count = jsonMean.length()
            featureNames = Array(count) { jsonNames.getString(it) }
            scalerMean = DoubleArray(count) { jsonMean.getDouble(it) }
            scalerScale = DoubleArray(count) { jsonScale.getDouble(it) }
            weights = DoubleArray(count) { jsonWeights.getDouble(it) }
            malignantPreset = DoubleArray(count) { jsonMal.getDouble(it) }
            benignPreset = DoubleArray(count) { jsonBen.getDouble(it) }
            intercept = json.getDouble("intercept")

            isReady = true
        } catch (e: Exception) {
            e.printStackTrace()
            isReady = false
        }
    }

    fun predict(inputFeatures: DoubleArray): PredictionResult {
        if (!isReady || inputFeatures.size != 30) {
            return PredictionResult(1, 0.0, 100.0, "UNKNOWN", "")
        }

        // Standardize features: z_i = (x_i - mean_i) / scale_i
        var linearLogOdds = intercept
        for (i in 0 until 30) {
            val standardized = (inputFeatures[i] - scalerMean[i]) / scalerScale[i]
            linearLogOdds += weights[i] * standardized
        }

        // Sigmoid Activation: P(Benign / Class 1) = 1 / (1 + exp(-z))
        val probBenign = 1.0 / (1.0 + exp(-linearLogOdds))
        val probMalignant = 1.0 - probBenign

        val predictedClass = if (probBenign >= 0.5) 1 else 0
        val label = if (predictedClass == 0) "MALIGNANT (High Risk)" else "BENIGN (Non-Cancerous)"
        val advice = if (predictedClass == 0) {
            "Morphological parameters indicate high risk of malignancy. Immediate biopsy confirmation & oncological consultation recommended."
        } else {
            "Morphological parameters indicate benign non-cancerous tissue. Routine follow-up mammography as clinically indicated."
        }

        return PredictionResult(
            predictedClass = predictedClass,
            probMalignant = probMalignant * 100.0,
            probBenign = probBenign * 100.0,
            diagnosisLabel = label,
            clinicalAdvice = advice
        )
    }
}
